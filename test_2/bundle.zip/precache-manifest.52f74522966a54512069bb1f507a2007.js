self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "33e916dc7460ad1c2049673189aa61e9",
    "url": "/index.html"
  },
  {
    "revision": "c47911609c28bd98e1fe",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "b19cd240714f37a45b38",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "c47911609c28bd98e1fe",
    "url": "/static/js/2.4bfc9216.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.4bfc9216.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b19cd240714f37a45b38",
    "url": "/static/js/main.69290fdb.chunk.js"
  },
  {
    "revision": "149be8df7aaaa37bb281",
    "url": "/static/js/runtime-main.b78e9312.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);